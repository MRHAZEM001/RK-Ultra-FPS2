package com.rk.ultrafps;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public final class RKUltraFPSClient implements ClientModInitializer {
    private static KeyMapping openSettingsKey;

    @Override
    public void onInitializeClient() {
        RKUltraFPSConfig.load();

        openSettingsKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.rk_ultra_fps.open_settings",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyMapping.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openSettingsKey.consumeClick()) {
                Minecraft mc = Minecraft.getInstance();
                if (mc.screen instanceof RKUltraFPSSettingsScreen) {
                    mc.setScreen(null);
                } else {
                    mc.setScreen(new RKUltraFPSSettingsScreen());
                }
            }
        });
    }

    public static void showMessage(String message) {
        Minecraft client = Minecraft.getInstance();
        if (client.player != null) {
            client.player.displayClientMessage(Component.literal("[RK Ultra FPS] " + message), true);
        }
    }
}
