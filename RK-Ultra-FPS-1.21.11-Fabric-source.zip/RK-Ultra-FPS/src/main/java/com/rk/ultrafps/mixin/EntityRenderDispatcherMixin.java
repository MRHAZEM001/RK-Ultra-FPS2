package com.rk.ultrafps.mixin;

import com.rk.ultrafps.RKUltraFPSConfig;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.world.entity.EntityType;
import com.mojang.blaze3d.vertex.PoseStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {
    @Inject(method = "submit", at = @At("HEAD"), cancellable = true)
    private <S extends EntityRenderState> void rkUltraFPS$filterEntityRender(
            S state,
            CameraRenderState cameraState,
            double x,
            double y,
            double z,
            PoseStack poseStack,
            SubmitNodeCollector collector,
            CallbackInfo ci
    ) {
        if (state == null || state.entityType == null) return;

        if (RKUltraFPSConfig.hideNonPlayerEntities && state.entityType != EntityType.PLAYER) {
            ci.cancel();
            return;
        }
        if (RKUltraFPSConfig.hideDroppedItems && state.entityType == EntityType.ITEM) {
            ci.cancel();
            return;
        }
        if (RKUltraFPSConfig.hideExperienceOrbs && state.entityType == EntityType.EXPERIENCE_ORB) {
            ci.cancel();
        }
    }
}
