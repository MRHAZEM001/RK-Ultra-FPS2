package com.rk.ultrafps;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** A small native Minecraft settings screen. */
public final class RKUltraFPSSettingsScreen extends Screen {
    private Button particlesButton;
    private Button droppedItemsButton;
    private Button xpButton;
    private Button blockEntitiesButton;
    private Button otherEntitiesButton;
    private Button shadowsButton;

    public RKUltraFPSSettingsScreen() {
        super(Component.literal("RK Ultra FPS Settings"));
    }

    @Override
    protected void init() {
        int buttonWidth = Math.min(220, Math.max(132, this.width - 24));
        int left = (this.width - buttonWidth) / 2;
        int startY = Math.max(55, this.height / 2 - 100);
        int gap = 25;

        particlesButton = addRenderableWidget(Button.builder(label("Hạt/Particles", RKUltraFPSConfig.disableParticles), b -> {
            RKUltraFPSConfig.disableParticles = !RKUltraFPSConfig.disableParticles;
            changed();
        }).bounds(left, startY, buttonWidth, 20).build());

        droppedItemsButton = addRenderableWidget(Button.builder(label("Item rơi", RKUltraFPSConfig.hideDroppedItems), b -> {
            RKUltraFPSConfig.hideDroppedItems = !RKUltraFPSConfig.hideDroppedItems;
            changed();
        }).bounds(left, startY + gap, buttonWidth, 20).build());

        xpButton = addRenderableWidget(Button.builder(label("Cầu kinh nghiệm (XP)", RKUltraFPSConfig.hideExperienceOrbs), b -> {
            RKUltraFPSConfig.hideExperienceOrbs = !RKUltraFPSConfig.hideExperienceOrbs;
            changed();
        }).bounds(left, startY + gap * 2, buttonWidth, 20).build());

        blockEntitiesButton = addRenderableWidget(Button.builder(label("Mô hình block đặc biệt", RKUltraFPSConfig.hideBlockEntities), b -> {
            RKUltraFPSConfig.hideBlockEntities = !RKUltraFPSConfig.hideBlockEntities;
            changed();
        }).bounds(left, startY + gap * 3, buttonWidth, 20).build());

        otherEntitiesButton = addRenderableWidget(Button.builder(label("Sinh vật/entity khác", RKUltraFPSConfig.hideNonPlayerEntities), b -> {
            RKUltraFPSConfig.hideNonPlayerEntities = !RKUltraFPSConfig.hideNonPlayerEntities;
            changed();
        }).bounds(left, startY + gap * 4, buttonWidth, 20).build());

        shadowsButton = addRenderableWidget(Button.builder(label("Bóng của entity", RKUltraFPSConfig.hideEntityShadows), b -> {
            RKUltraFPSConfig.hideEntityShadows = !RKUltraFPSConfig.hideEntityShadows;
            changed();
        }).bounds(left, startY + gap * 5, buttonWidth, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Đóng / Close"), b -> onClose())
                .bounds(left, Math.min(this.height - 30, startY + gap * 6), buttonWidth, 20).build());
    }

    private static Component label(String name, boolean enabled) {
        return Component.literal(name + ": " + (enabled ? "BẬT" : "TẮT"));
    }

    private void changed() {
        RKUltraFPSConfig.save();
        particlesButton.setMessage(label("Hạt/Particles", RKUltraFPSConfig.disableParticles));
        droppedItemsButton.setMessage(label("Item rơi", RKUltraFPSConfig.hideDroppedItems));
        xpButton.setMessage(label("Cầu kinh nghiệm (XP)", RKUltraFPSConfig.hideExperienceOrbs));
        blockEntitiesButton.setMessage(label("Mô hình block đặc biệt", RKUltraFPSConfig.hideBlockEntities));
        otherEntitiesButton.setMessage(label("Sinh vật/entity khác", RKUltraFPSConfig.hideNonPlayerEntities));
        shadowsButton.setMessage(label("Bóng của entity", RKUltraFPSConfig.hideEntityShadows));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, 22, 0xFFFFFF);
        graphics.drawCenteredString(this.font, Component.literal("Right Shift = mở/đóng menu"), this.width / 2, 37, 0xB8D7FF);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(null);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
