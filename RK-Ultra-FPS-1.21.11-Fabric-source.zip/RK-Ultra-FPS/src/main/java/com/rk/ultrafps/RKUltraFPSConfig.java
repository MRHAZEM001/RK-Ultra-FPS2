package com.rk.ultrafps;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** User settings stored outside the mod JAR in the Minecraft config directory. */
public final class RKUltraFPSConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger("RK Ultra FPS");
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("rk-ultra-fps.properties");

    public static boolean disableParticles = true;
    public static boolean hideDroppedItems = true;
    public static boolean hideExperienceOrbs = false;
    public static boolean hideBlockEntities = false;
    public static boolean hideNonPlayerEntities = false;
    public static boolean hideEntityShadows = true;

    private RKUltraFPSConfig() {}

    public static void load() {
        if (Files.isRegularFile(FILE)) {
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(FILE)) {
                p.load(in);
                disableParticles = Boolean.parseBoolean(p.getProperty("disableParticles", "true"));
                hideDroppedItems = Boolean.parseBoolean(p.getProperty("hideDroppedItems", "true"));
                hideExperienceOrbs = Boolean.parseBoolean(p.getProperty("hideExperienceOrbs", "false"));
                hideBlockEntities = Boolean.parseBoolean(p.getProperty("hideBlockEntities", "false"));
                hideNonPlayerEntities = Boolean.parseBoolean(p.getProperty("hideNonPlayerEntities", "false"));
                hideEntityShadows = Boolean.parseBoolean(p.getProperty("hideEntityShadows", "true"));
            } catch (IOException e) {
                LOGGER.error("Could not load config from {}", FILE, e);
            }
        }
        applyVanillaOptions();
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("disableParticles", Boolean.toString(disableParticles));
        p.setProperty("hideDroppedItems", Boolean.toString(hideDroppedItems));
        p.setProperty("hideExperienceOrbs", Boolean.toString(hideExperienceOrbs));
        p.setProperty("hideBlockEntities", Boolean.toString(hideBlockEntities));
        p.setProperty("hideNonPlayerEntities", Boolean.toString(hideNonPlayerEntities));
        p.setProperty("hideEntityShadows", Boolean.toString(hideEntityShadows));
        try {
            Files.createDirectories(FILE.getParent());
            try (OutputStream out = Files.newOutputStream(FILE)) {
                p.store(out, "RK Ultra FPS settings. true/false values can also be edited by hand.");
            }
        } catch (IOException e) {
            LOGGER.error("Could not save config to {}", FILE, e);
        }
        applyVanillaOptions();
    }

    private static void applyVanillaOptions() {
        Minecraft client = Minecraft.getInstance();
        if (client != null && client.options != null) {
            client.options.entityShadows().set(!hideEntityShadows);
            client.options.save();
        }
    }
}
