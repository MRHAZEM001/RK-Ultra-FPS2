package com.rk.ultrafps.mixin;

import com.rk.ultrafps.RKUltraFPSConfig;
import net.minecraft.client.Camera;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.client.particle.ParticlesRenderState;
import net.minecraft.client.renderer.culling.Frustum;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ParticleEngine.class)
public abstract class ParticleEngineMixin {
    @Inject(method = "add", at = @At("HEAD"), cancellable = true)
    private void rkUltraFPS$discardNewParticles(Particle particle, CallbackInfo ci) {
        if (RKUltraFPSConfig.disableParticles) {
            ci.cancel();
        }
    }

    @Inject(method = "extract", at = @At("HEAD"), cancellable = true)
    private void rkUltraFPS$skipParticleRendering(
            ParticlesRenderState renderState,
            Frustum frustum,
            Camera camera,
            float tickProgress,
            CallbackInfo ci
    ) {
        if (RKUltraFPSConfig.disableParticles) {
            ci.cancel();
        }
    }
}
