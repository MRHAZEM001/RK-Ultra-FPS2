# RK Ultra FPS — Minecraft Java 1.21.11 / Fabric

Mod phía client, có menu settings, file cấu hình riêng và các công tắc giảm hiệu ứng render. Dự án được cấu hình để build bằng GitHub Actions, nên có thể biên dịch trên GitHub mà không cần cài Java/Gradle trên điện thoại.

## Chức năng

- **Hạt/Particles:** chặn thêm hạt mới và bỏ qua bước đưa hạt vào render khi bật.
- **Item rơi:** ẩn mô hình item đang nằm dưới đất; không xóa item khỏi thế giới và vẫn có thể nhặt được.
- **Cầu kinh nghiệm (XP):** ẩn mô hình cầu XP; XP vẫn tồn tại trong thế giới.
- **Mô hình block đặc biệt:** ẩn mô hình block entity như rương, biển, beacon, lò, spawner… Không ẩn các block địa hình bình thường.
- **Sinh vật/entity khác:** ẩn render các entity không phải người chơi. Tùy chọn này có thể làm không nhìn thấy mob, vật phẩm và đạn/phóng vật thể; chỉ bật khi thực sự cần.
- **Bóng của entity:** tắt bóng entity qua tùy chọn đồ họa gốc của Minecraft.
- **Menu:** nhấn **Right Shift** để mở/đóng. Cài đặt được lưu trong `config/rk-ultra-fps.properties`.

## Yêu cầu

- Minecraft **Java Edition 1.21.11**
- Fabric Loader **0.18.1 trở lên**
- Java 21 (dành cho môi trường build/chạy Minecraft 1.21.11)
- Fabric API phù hợp với Minecraft 1.21.11

## Build bằng GitHub Actions trên điện thoại

Có hai cách:

**Cách A — tải source ZIP lên GitHub bằng điện thoại (ít phải tải từng file):**
1. Tạo repository mới trên GitHub, ví dụ `RK-Ultra-FPS`.
2. Tải file `RK-Ultra-FPS-1.21.11-Fabric-source.zip` lên thư mục gốc của repository.
3. Trong repository, chọn **Add file → Create new file**. Tên file nhập chính xác là `.github/workflows/build.yml`.
4. Mở file `BUILD-FROM-ZIP-WORKFLOW.txt` trong source ZIP, sao chép phần YAML từ dòng `name: Build RK Ultra FPS from source ZIP` tới hết file, dán vào file GitHub rồi nhấn **Commit changes**. GitHub sẽ chạy workflow tự động.
5. Mở tab **Actions**, chọn lần chạy mới nhất. Khi có dấu tick xanh, mở lần chạy và tải artifact `RK-Ultra-FPS-Minecraft-1.21.11-Fabric` trong mục **Artifacts**. Giải nén artifact để lấy `.jar`.

**Cách B — tải nguyên các file đã giải nén vào repository:** tải các file và thư mục bên trong dự án lên GitHub, giữ nguyên đường dẫn như `src` và `.github/workflows`. Workflow có sẵn sẽ build khi push hoặc có thể chạy bằng **Actions → Build RK Ultra FPS → Run workflow**.

Nếu workflow thất bại, mở log của bước **Build mod JAR** để xem lỗi. Không tải được JAR từ lần chạy lỗi.

## Cài mod

1. Cài Fabric Loader cho đúng bản **Minecraft Java 1.21.11**.
2. Tải Fabric API dành cho **1.21.11**.
3. Chép cả `rk-ultra-fps-1.0.0.jar` và file Fabric API vào thư mục `mods` của đúng thư mục game.
4. Mở profile Fabric trong Minecraft Launcher.

## Giới hạn cần biết

Mod này **không thể đảm bảo tăng FPS trên mọi máy**. Việc ẩn mô hình giúp giảm render nhưng không xóa entity/block khỏi thế giới và không làm giảm hoàn toàn tải CPU/server. Các block địa hình thông thường vẫn hiển thị. Shader, GPU, RAM, khoảng cách render, resource pack và server cũng có thể gây lag. Hãy sao lưu thế giới và bật/tắt từng tùy chọn để kiểm tra hiệu quả.

## Tệp build

Khi build thành công, JAR nằm trong `build/libs/`. JAR đầu ra dự kiến là `rk-ultra-fps-1.0.0.jar`.
